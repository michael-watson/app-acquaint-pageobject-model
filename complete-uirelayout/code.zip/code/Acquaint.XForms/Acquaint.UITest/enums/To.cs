﻿namespace Acquaint.UITest.enums
{
	public enum To
	{
		FirstName,
		LastName,
		Company,
		Title,
		Phone,
		Email,
		Street,
		City,
		State,
		Zip
	}
}